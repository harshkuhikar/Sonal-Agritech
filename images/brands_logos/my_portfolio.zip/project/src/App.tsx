import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Navigation } from './components/Navigation';
import { Home } from './pages/Home';
import { About } from './pages/About';
import { Projects } from './pages/Projects';
import { Skills } from './pages/Skills';
import { Contact } from './pages/Contact';
import { AnimatedCursor } from './components/AnimatedCursor';

gsap.registerPlugin(ScrollTrigger);

function App() {
  useEffect(() => {
    // Global GSAP configuration
    gsap.config({
      force3D: true,
      nullTargetWarn: false
    });

    // Custom scrollbar styles
    const style = document.createElement('style');
    style.innerHTML = `
      ::-webkit-scrollbar {
        width: 8px;
      }
      ::-webkit-scrollbar-track {
        background: #1a1a1a;
      }
      ::-webkit-scrollbar-thumb {
        background: linear-gradient(45deg, #667eea, #764ba2);
        border-radius: 4px;
      }
      ::-webkit-scrollbar-thumb:hover {
        background: linear-gradient(45deg, #764ba2, #667eea);
      }
      
      html {
        scroll-behavior: smooth;
      }
      
      body {
        overflow-x: hidden;
        background: #000;
      }

      /* Gradient animations */
      @keyframes gradientShift {
        0% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
        100% { background-position: 0% 50%; }
      }

      /* Performance optimizations */
      .gpu-accelerated {
        transform: translateZ(0);
        backface-visibility: hidden;
        perspective: 1000px;
      }

      /* Page transitions */
      .page-transition {
        opacity: 0;
        transform: translateY(50px);
        animation: pageEnter 0.8s ease-out forwards;
      }

      @keyframes pageEnter {
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }
    `;
    document.head.appendChild(style);

    return () => {
      document.head.removeChild(style);
    };
  }, []);

  return (
    <Router>
      <div className="min-h-screen bg-black overflow-x-hidden">
        <AnimatedCursor />
        <Navigation />
        
        <main className="relative">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/skills" element={<Skills />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
        
        <footer className="bg-black/90 backdrop-blur-sm border-t border-white/10 py-12">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid md:grid-cols-4 gap-8">
              <div className="col-span-2">
                <h3 className="text-2xl font-bold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent mb-4">
                  HARSH KUHIKAR
                </h3>
                <p className="text-gray-400 leading-relaxed mb-4">
                  Creative Developer & 3D Animation Specialist crafting immersive digital experiences 
                  that push the boundaries of web development.
                </p>
              </div>
              
              <div>
                <h4 className="text-white font-semibold mb-4">Quick Links</h4>
                <ul className="space-y-2">
                  <li><a href="/" className="text-gray-400 hover:text-white transition-colors duration-300">Home</a></li>
                  <li><a href="/about" className="text-gray-400 hover:text-white transition-colors duration-300">About</a></li>
                  <li><a href="/projects" className="text-gray-400 hover:text-white transition-colors duration-300">Projects</a></li>
                  <li><a href="/contact" className="text-gray-400 hover:text-white transition-colors duration-300">Contact</a></li>
                </ul>
              </div>
              
              <div>
                <h4 className="text-white font-semibold mb-4">Services</h4>
                <ul className="space-y-2">
                  <li><span className="text-gray-400">3D Web Development</span></li>
                  <li><span className="text-gray-400">React Applications</span></li>
                  <li><span className="text-gray-400">WebGL & Shaders</span></li>
                  <li><span className="text-gray-400">Animation & GSAP</span></li>
                  <li><span className="text-gray-400">UI/UX Design</span></li>
                </ul>
              </div>
            </div>
            
            <div className="border-t border-white/10 mt-8 pt-8 text-center">
              <p className="text-gray-400">
                © 2024 Harsh Kuhikar. All rights reserved. Built with React, Three.js, GSAP & lots of ☕
              </p>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;