import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { 
  OrbitControls, 
  Environment, 
  PerspectiveCamera,
  EffectComposer,
  Bloom,
  ChromaticAberration,
  Vignette
} from '@react-three/drei';
import { AnimatedSphere } from './AnimatedSphere';
import { FloatingGeometry } from './FloatingGeometry';
import { ParticleField } from './ParticleField';

interface Scene3DProps {
  className?: string;
  enableControls?: boolean;
}

export const Scene3D: React.FC<Scene3DProps> = ({ 
  className = '', 
  enableControls = false 
}) => {
  return (
    <div className={`w-full h-full ${className}`}>
      <Canvas>
        <Suspense fallback={null}>
          <PerspectiveCamera makeDefault position={[0, 0, 15]} fov={75} />
          
          {enableControls && <OrbitControls enableZoom={false} />}
          
          {/* Lighting */}
          <ambientLight intensity={0.2} />
          <directionalLight position={[10, 10, 5]} intensity={1} />
          <pointLight position={[-10, -10, -5]} intensity={0.5} color="#ff6b6b" />
          <pointLight position={[10, -10, 5]} intensity={0.5} color="#4ecdc4" />
          
          {/* 3D Elements */}
          <AnimatedSphere position={[0, 0, 0]} scale={2} />
          <AnimatedSphere position={[5, 3, -2]} scale={1} color1="#ff9ff3" color2="#54a0ff" color3="#5f27cd" />
          <AnimatedSphere position={[-4, -2, 3]} scale={1.5} color1="#00d2d3" color2="#ff9ff3" color3="#54a0ff" />
          
          <FloatingGeometry count={30} radius={15} />
          <ParticleField count={1500} radius={25} />
          
          {/* Environment */}
          <Environment preset="night" />
          
          {/* Post-processing effects */}
          <EffectComposer>
            <Bloom intensity={0.5} luminanceThreshold={0.9} />
            <ChromaticAberration offset={[0.002, 0.002]} />
            <Vignette eskil={false} offset={0.1} darkness={0.5} />
          </EffectComposer>
        </Suspense>
      </Canvas>
    </div>
  );
};