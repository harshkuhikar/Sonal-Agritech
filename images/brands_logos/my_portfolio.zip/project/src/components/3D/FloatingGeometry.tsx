import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Box, Sphere, Octahedron, Torus, Cone } from '@react-three/drei';
import * as THREE from 'three';
import { gsap } from 'gsap';

interface FloatingGeometryProps {
  count?: number;
  radius?: number;
}

export const FloatingGeometry: React.FC<FloatingGeometryProps> = ({
  count = 50,
  radius = 20
}) => {
  const groupRef = useRef<THREE.Group>(null);
  
  const geometries = useMemo(() => {
    const shapes = [];
    const geometryTypes = [Box, Sphere, Octahedron, Torus, Cone];
    
    for (let i = 0; i < count; i++) {
      const GeometryComponent = geometryTypes[Math.floor(Math.random() * geometryTypes.length)];
      const position: [number, number, number] = [
        (Math.random() - 0.5) * radius * 2,
        (Math.random() - 0.5) * radius * 2,
        (Math.random() - 0.5) * radius * 2
      ];
      
      const scale = Math.random() * 0.5 + 0.2;
      const color = new THREE.Color().setHSL(Math.random(), 0.7, 0.6);
      
      shapes.push({
        Component: GeometryComponent,
        position,
        scale,
        color,
        rotationSpeed: (Math.random() - 0.5) * 0.02,
        floatSpeed: Math.random() * 0.01 + 0.005,
        id: i
      });
    }
    
    return shapes;
  }, [count, radius]);

  useFrame((state) => {
    if (groupRef.current) {
      groupRef.current.rotation.y += 0.001;
      
      groupRef.current.children.forEach((child, index) => {
        const geometry = geometries[index];
        child.rotation.x += geometry.rotationSpeed;
        child.rotation.y += geometry.rotationSpeed * 0.7;
        child.position.y += Math.sin(state.clock.elapsedTime * geometry.floatSpeed + index) * 0.01;
      });
    }
  });

  return (
    <group ref={groupRef}>
      {geometries.map((geometry, index) => {
        const { Component, position, scale, color } = geometry;
        
        return (
          <Component
            key={index}
            position={position}
            scale={scale}
            args={Component === Torus ? [0.5, 0.2, 16, 32] : undefined}
          >
            <meshPhysicalMaterial
              color={color}
              metalness={0.8}
              roughness={0.2}
              transmission={0.3}
              transparent
              opacity={0.8}
            />
          </Component>
        );
      })}
    </group>
  );
};