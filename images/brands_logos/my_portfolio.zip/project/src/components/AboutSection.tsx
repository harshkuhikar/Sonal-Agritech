import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export const AboutSection: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Animate cards on scroll
      cardsRef.current.forEach((card, index) => {
        if (card) {
          gsap.fromTo(card, 
            { 
              y: 100, 
              opacity: 0,
              rotateY: 45,
              scale: 0.8
            },
            {
              y: 0, 
              opacity: 1,
              rotateY: 0,
              scale: 1,
              duration: 1.2,
              delay: index * 0.2,
              ease: "power3.out",
              scrollTrigger: {
                trigger: card,
                start: "top bottom-=100",
                end: "bottom top",
                toggleActions: "play none none reverse"
              }
            }
          );

          // Continuous floating animation
          gsap.to(card, {
            y: -10,
            duration: 2 + index * 0.5,
            repeat: -1,
            yoyo: true,
            ease: "power2.inOut",
            delay: index * 0.3
          });
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const skills = [
    { name: "React & Next.js", level: 95, color: "from-blue-500 to-cyan-500" },
    { name: "Three.js & WebGL", level: 90, color: "from-purple-500 to-pink-500" },
    { name: "GSAP Animation", level: 88, color: "from-green-500 to-emerald-500" },
    { name: "TypeScript", level: 92, color: "from-orange-500 to-red-500" },
    { name: "Node.js", level: 85, color: "from-yellow-500 to-orange-500" },
    { name: "UI/UX Design", level: 87, color: "from-indigo-500 to-purple-500" }
  ];

  return (
    <section ref={sectionRef} className="min-h-screen py-20 px-4 bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIyMCIgcj0iMSIgZmlsbD0iIzMzMzMzMyIgZmlsbC1vcGFjaXR5PSIwLjEiLz4KPC9zdmc+')] opacity-50" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-20">
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 tracking-tight">
            About Me
          </h2>
          <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            I'm a passionate developer who brings ideas to life through code, creativity, and cutting-edge technology.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center mb-20">
          <div className="space-y-6">
            <div 
              ref={el => el && (cardsRef.current[0] = el)}
              className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20 hover:bg-white/20 transition-all duration-300"
            >
              <h3 className="text-2xl font-bold text-white mb-4">Frontend Specialist</h3>
              <p className="text-gray-300 leading-relaxed">
                Expert in modern React ecosystem with extensive experience in building responsive, 
                interactive web applications. Specialized in creating seamless user experiences 
                with advanced animations and 3D graphics.
              </p>
            </div>

            <div 
              ref={el => el && (cardsRef.current[1] = el)}
              className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20 hover:bg-white/20 transition-all duration-300"
            >
              <h3 className="text-2xl font-bold text-white mb-4">3D Animation Expert</h3>
              <p className="text-gray-300 leading-relaxed">
                Passionate about creating immersive 3D experiences using Three.js, WebGL, and 
                advanced animation libraries. I transform static designs into dynamic, 
                interactive masterpieces.
              </p>
            </div>
          </div>

          <div className="space-y-6">
            {skills.map((skill, index) => (
              <div 
                key={skill.name}
                ref={el => el && (cardsRef.current[index + 2] = el)}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20"
              >
                <div className="flex justify-between items-center mb-3">
                  <span className="text-white font-semibold">{skill.name}</span>
                  <span className="text-gray-300">{skill.level}%</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-3 overflow-hidden">
                  <div 
                    className={`h-full bg-gradient-to-r ${skill.color} rounded-full transition-all duration-1000 ease-out`}
                    style={{ width: `${skill.level}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center">
          <div 
            ref={el => el && (cardsRef.current[skills.length + 2] = el)}
            className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm rounded-2xl p-8 border border-white/20 max-w-4xl mx-auto"
          >
            <h3 className="text-3xl font-bold text-white mb-6">Let's Create Something Amazing</h3>
            <p className="text-gray-300 text-lg leading-relaxed mb-8">
              I'm always excited to work on innovative projects that push the boundaries 
              of web development. Let's collaborate and build the future of digital experiences together.
            </p>
            <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-3 rounded-full font-semibold hover:shadow-lg hover:scale-105 transition-all duration-300">
              Get In Touch
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};