import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ExternalLink, Github } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export const ProjectsSection: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const projectsRef = useRef<HTMLDivElement[]>([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      projectsRef.current.forEach((project, index) => {
        if (project) {
          gsap.fromTo(project, 
            { 
              y: 100, 
              opacity: 0,
              rotateX: 45,
              scale: 0.8
            },
            {
              y: 0, 
              opacity: 1,
              rotateX: 0,
              scale: 1,
              duration: 1.2,
              delay: index * 0.2,
              ease: "power3.out",
              scrollTrigger: {
                trigger: project,
                start: "top bottom-=100",
                end: "bottom top",
                toggleActions: "play none none reverse"
              }
            }
          );

          // Hover animations
          const handleMouseEnter = () => {
            gsap.to(project, {
              y: -10,
              scale: 1.05,
              duration: 0.3,
              ease: "power2.out"
            });
          };

          const handleMouseLeave = () => {
            gsap.to(project, {
              y: 0,
              scale: 1,
              duration: 0.3,
              ease: "power2.out"
            });
          };

          project.addEventListener('mouseenter', handleMouseEnter);
          project.addEventListener('mouseleave', handleMouseLeave);
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const projects = [
    {
      title: "3D Portfolio Experience",
      description: "An immersive 3D portfolio website built with Three.js and React, featuring interactive 3D models, particle systems, and advanced animations.",
      image: "https://images.pexels.com/photos/1181472/pexels-photo-1181472.jpeg?auto=compress&cs=tinysrgb&w=800",
      technologies: ["React", "Three.js", "GSAP", "TypeScript"],
      github: "#",
      live: "#"
    },
    {
      title: "Interactive Data Visualization",
      description: "A dynamic dashboard with real-time data visualization using WebGL shaders and custom animations for enhanced user engagement.",
      image: "https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800",
      technologies: ["D3.js", "WebGL", "Node.js", "MongoDB"],
      github: "#",
      live: "#"
    },
    {
      title: "AR Product Viewer",
      description: "An augmented reality application that allows users to visualize products in their environment using WebXR and advanced 3D rendering.",
      image: "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=800",
      technologies: ["WebXR", "Three.js", "React", "GSAP"],
      github: "#",
      live: "#"
    },
    {
      title: "Real-time Collaboration Tool",
      description: "A multi-user collaborative workspace with live cursors, real-time updates, and smooth animations for seamless teamwork.",
      image: "https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800",
      technologies: ["React", "WebSocket", "Node.js", "Redis"],
      github: "#",
      live: "#"
    },
    {
      title: "AI-Powered Code Editor",
      description: "An intelligent code editor with AI-assisted coding, syntax highlighting, and collaborative features with real-time synchronization.",
      image: "https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=800",
      technologies: ["Monaco Editor", "AI/ML", "WebSocket", "TypeScript"],
      github: "#",
      live: "#"
    },
    {
      title: "Blockchain Visualization",
      description: "A comprehensive blockchain explorer with interactive 3D network visualization and real-time transaction tracking.",
      image: "https://images.pexels.com/photos/730547/pexels-photo-730547.jpeg?auto=compress&cs=tinysrgb&w=800",
      technologies: ["Web3.js", "Three.js", "React", "Ethereum"],
      github: "#",
      live: "#"
    }
  ];

  return (
    <section ref={sectionRef} className="min-h-screen py-20 px-4 bg-gradient-to-br from-purple-900 via-blue-900 to-gray-900 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGRlZnM+CjxwYXR0ZXJuIGlkPSJncmlkIiB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiPgo8cGF0aCBkPSJNIDYwIDAgTCAwIDAgMCA2MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMzMzMzMzIiBzdHJva2Utd2lkdGg9IjEiIHN0cm9rZS1vcGFjaXR5PSIwLjEiLz4KPC9wYXR0ZXJuPgo8L2RlZnM+CjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz4KPC9zdmc+')] opacity-30" />
      
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-20">
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 tracking-tight">
            Featured Projects
          </h2>
          <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Explore my latest work showcasing innovative solutions and cutting-edge technologies.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <div 
              key={project.title}
              ref={el => el && (projectsRef.current[index] = el)}
              className="bg-white/10 backdrop-blur-sm rounded-2xl overflow-hidden border border-white/20 hover:bg-white/20 transition-all duration-300 cursor-pointer"
              style={{ perspective: '1000px' }}
            >
              <div className="relative overflow-hidden">
                <img 
                  src={project.image} 
                  alt={project.title}
                  className="w-full h-48 object-cover transition-transform duration-300 hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                <div className="absolute top-4 right-4 flex space-x-2">
                  <a 
                    href={project.github}
                    className="p-2 bg-white/20 backdrop-blur-sm rounded-full text-white hover:bg-white/30 transition-all duration-300"
                  >
                    <Github size={16} />
                  </a>
                  <a 
                    href={project.live}
                    className="p-2 bg-white/20 backdrop-blur-sm rounded-full text-white hover:bg-white/30 transition-all duration-300"
                  >
                    <ExternalLink size={16} />
                  </a>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-white mb-3">{project.title}</h3>
                <p className="text-gray-300 text-sm mb-4 leading-relaxed">{project.description}</p>
                
                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech) => (
                    <span 
                      key={tech}
                      className="px-3 py-1 bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-white text-xs rounded-full border border-white/10"
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-20">
          <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-8 py-3 rounded-full font-semibold hover:shadow-lg hover:scale-105 transition-all duration-300">
            View All Projects
          </button>
        </div>
      </div>
    </section>
  );
};