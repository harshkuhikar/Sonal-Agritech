import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Scene3D } from '../components/Scene3D';
import { Code, Palette, Zap, Award, Users, Coffee } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export const About: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const statsRef = useRef<HTMLDivElement>(null);
  const skillsRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Stats animation
      gsap.fromTo('.stat-card',
        { y: 100, opacity: 0, rotationY: 45 },
        {
          y: 0,
          opacity: 1,
          rotationY: 0,
          duration: 1.2,
          stagger: 0.2,
          ease: "power3.out",
          scrollTrigger: {
            trigger: statsRef.current,
            start: "top bottom-=100",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Skills animation
      gsap.fromTo('.skill-item',
        { x: -100, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 1,
          stagger: 0.1,
          ease: "power3.out",
          scrollTrigger: {
            trigger: skillsRef.current,
            start: "top bottom-=100",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Timeline animation
      gsap.fromTo('.timeline-item',
        { y: 50, opacity: 0, scale: 0.8 },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          duration: 0.8,
          stagger: 0.3,
          ease: "back.out(1.7)",
          scrollTrigger: {
            trigger: timelineRef.current,
            start: "top bottom-=100",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Skill progress bars animation
      gsap.fromTo('.skill-progress',
        { width: '0%' },
        {
          width: (index, target) => target.dataset.progress + '%',
          duration: 2,
          ease: "power2.out",
          scrollTrigger: {
            trigger: skillsRef.current,
            start: "top bottom-=100",
            toggleActions: "play none none reverse"
          }
        }
      );

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const stats = [
    { icon: <Code className="w-8 h-8" />, number: "50+", label: "Projects Completed", color: "from-blue-500 to-cyan-500" },
    { icon: <Users className="w-8 h-8" />, number: "30+", label: "Happy Clients", color: "from-green-500 to-emerald-500" },
    { icon: <Award className="w-8 h-8" />, number: "5+", label: "Years Experience", color: "from-purple-500 to-pink-500" },
    { icon: <Coffee className="w-8 h-8" />, number: "1000+", label: "Cups of Coffee", color: "from-orange-500 to-red-500" }
  ];

  const skills = [
    { name: "React & Next.js", level: 95, category: "Frontend" },
    { name: "Three.js & WebGL", level: 90, category: "3D Graphics" },
    { name: "GSAP Animation", level: 92, category: "Animation" },
    { name: "TypeScript", level: 88, category: "Language" },
    { name: "Node.js & Express", level: 85, category: "Backend" },
    { name: "Python & AI/ML", level: 80, category: "Data Science" },
    { name: "UI/UX Design", level: 87, category: "Design" },
    { name: "WebGL Shaders", level: 83, category: "Graphics" }
  ];

  const timeline = [
    {
      year: "2024",
      title: "Senior Full-Stack Developer",
      company: "Tech Innovation Labs",
      description: "Leading 3D web development projects and mentoring junior developers in advanced animation techniques."
    },
    {
      year: "2023",
      title: "3D Web Developer",
      company: "Creative Digital Agency",
      description: "Specialized in creating immersive 3D experiences for high-profile clients using Three.js and WebGL."
    },
    {
      year: "2022",
      title: "Frontend Developer",
      company: "Startup Accelerator",
      description: "Built responsive web applications with modern frameworks and implemented complex animations."
    },
    {
      year: "2021",
      title: "Junior Developer",
      company: "Web Solutions Inc",
      description: "Started my journey in web development, focusing on React and modern JavaScript frameworks."
    }
  ];

  return (
    <div className="page-transition">
      <section ref={sectionRef} className="min-h-screen pt-20">
        {/* Hero Section */}
        <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
            <Scene3D containerId="about-scene" className="w-full h-full" />
          </div>
          
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/30 to-black/70 z-10" />
          
          <div className="relative z-20 text-center px-4 max-w-6xl mx-auto">
            <h1 className="text-6xl md:text-8xl font-bold text-white mb-8 tracking-tight">
              About Me
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 max-w-4xl mx-auto leading-relaxed">
              I'm a passionate developer who transforms ideas into stunning digital experiences through 
              cutting-edge technology, creative problem-solving, and meticulous attention to detail.
            </p>
          </div>
        </div>

        {/* Stats Section */}
        <div ref={statsRef} className="py-20 px-4 bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <div 
                  key={stat.label}
                  className="stat-card text-center group cursor-pointer"
                >
                  <div className="relative bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-all duration-500">
                    <div className={`inline-flex p-4 bg-gradient-to-r ${stat.color} rounded-2xl text-white mb-4 group-hover:scale-110 transition-transform duration-500`}>
                      {stat.icon}
                    </div>
                    <div className="text-4xl font-bold text-white mb-2 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:from-blue-400 group-hover:to-purple-500 transition-all duration-500">
                      {stat.number}
                    </div>
                    <div className="text-gray-300 font-medium group-hover:text-gray-200 transition-colors duration-500">
                      {stat.label}
                    </div>
                    
                    {/* Glow effect */}
                    <div className={`absolute -inset-2 bg-gradient-to-r ${stat.color} opacity-0 group-hover:opacity-20 transition-opacity duration-500 rounded-2xl blur-xl`} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Skills Section */}
        <div ref={skillsRef} className="py-20 px-4 bg-gradient-to-br from-purple-900 via-blue-900 to-gray-900">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 tracking-tight">
                Technical Skills
              </h2>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                Expertise across the full spectrum of modern web development technologies.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {skills.map((skill, index) => (
                <div 
                  key={skill.name}
                  className="skill-item bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:bg-white/10 transition-all duration-300"
                >
                  <div className="flex justify-between items-center mb-3">
                    <div>
                      <span className="text-white font-semibold text-lg">{skill.name}</span>
                      <span className="text-gray-400 text-sm ml-2">({skill.category})</span>
                    </div>
                    <span className="text-gray-300 font-medium">{skill.level}%</span>
                  </div>
                  <div className="w-full bg-gray-700/50 rounded-full h-3 overflow-hidden">
                    <div 
                      className="skill-progress h-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-full transition-all duration-1000 ease-out"
                      data-progress={skill.level}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Timeline Section */}
        <div ref={timelineRef} className="py-20 px-4 bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 tracking-tight">
                My Journey
              </h2>
              <p className="text-xl text-gray-300">
                The path that led me to become a 3D web development specialist.
              </p>
            </div>

            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-blue-500 via-purple-500 to-pink-500" />
              
              {timeline.map((item, index) => (
                <div 
                  key={item.year}
                  className="timeline-item relative flex items-start mb-12 last:mb-0"
                >
                  {/* Timeline dot */}
                  <div className="absolute left-6 w-4 h-4 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full border-4 border-gray-900" />
                  
                  {/* Content */}
                  <div className="ml-16 bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:bg-white/10 transition-all duration-300 group cursor-pointer">
                    <div className="flex items-center mb-3">
                      <span className="text-2xl font-bold text-transparent bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text">
                        {item.year}
                      </span>
                      <div className="ml-auto w-2 h-2 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:from-blue-400 group-hover:to-purple-500 transition-all duration-300">
                      {item.title}
                    </h3>
                    <p className="text-blue-400 font-medium mb-3">{item.company}</p>
                    <p className="text-gray-300 leading-relaxed group-hover:text-gray-200 transition-colors duration-300">
                      {item.description}
                    </p>
                    
                    {/* Glow effect */}
                    <div className="absolute -inset-2 bg-gradient-to-r from-blue-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl blur-xl" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Personal Section */}
        <div className="py-20 px-4 bg-gradient-to-br from-blue-900 via-purple-900 to-gray-900">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-5xl md:text-6xl font-bold text-white mb-8 tracking-tight">
              Beyond Code
            </h2>
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
              <p className="text-xl text-gray-300 leading-relaxed mb-6">
                When I'm not crafting digital experiences, you'll find me exploring the latest in 
                emerging technologies, contributing to open-source projects, or experimenting with 
                new animation techniques. I believe that the best developers are lifelong learners 
                who stay curious about the ever-evolving landscape of technology.
              </p>
              <p className="text-lg text-gray-400 leading-relaxed">
                I'm passionate about sharing knowledge with the developer community through 
                blog posts, tutorials, and speaking at tech conferences. My goal is to push 
                the boundaries of what's possible on the web while making complex technologies 
                accessible to everyone.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};