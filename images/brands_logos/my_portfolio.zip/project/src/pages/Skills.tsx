import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Scene3D } from '../components/Scene3D';
import { 
  Code, 
  Palette, 
  Database, 
  Smartphone, 
  Globe, 
  Zap,
  Brain,
  Layers,
  Monitor,
  Server,
  Cpu,
  Gamepad2
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export const Skills: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const skillCategoriesRef = useRef<HTMLDivElement>(null);
  const toolsRef = useRef<HTMLDivElement>(null);
  const certificationsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Skill categories animation
      gsap.fromTo('.skill-category',
        { y: 100, opacity: 0, rotationY: 45 },
        {
          y: 0,
          opacity: 1,
          rotationY: 0,
          duration: 1.2,
          stagger: 0.2,
          ease: "power3.out",
          scrollTrigger: {
            trigger: skillCategoriesRef.current,
            start: "top bottom-=100",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Tools animation
      gsap.fromTo('.tool-item',
        { scale: 0, opacity: 0, rotation: 180 },
        {
          scale: 1,
          opacity: 1,
          rotation: 0,
          duration: 0.8,
          stagger: 0.1,
          ease: "back.out(1.7)",
          scrollTrigger: {
            trigger: toolsRef.current,
            start: "top bottom-=100",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Certifications animation
      gsap.fromTo('.certification-card',
        { x: -100, opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 1,
          stagger: 0.2,
          ease: "power3.out",
          scrollTrigger: {
            trigger: certificationsRef.current,
            start: "top bottom-=100",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Skill progress animation
      gsap.fromTo('.skill-progress',
        { width: '0%' },
        {
          width: (index, target) => target.dataset.progress + '%',
          duration: 2,
          ease: "power2.out",
          scrollTrigger: {
            trigger: skillCategoriesRef.current,
            start: "top bottom-=100",
            toggleActions: "play none none reverse"
          }
        }
      );

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const skillCategories = [
    {
      icon: <Code className="w-8 h-8" />,
      title: "Frontend Development",
      description: "Creating stunning user interfaces with modern frameworks and libraries",
      color: "from-blue-500 to-cyan-500",
      skills: [
        { name: "React & Next.js", level: 95 },
        { name: "TypeScript", level: 92 },
        { name: "Vue.js", level: 85 },
        { name: "Angular", level: 80 },
        { name: "Svelte", level: 78 }
      ]
    },
    {
      icon: <Layers className="w-8 h-8" />,
      title: "3D Graphics & Animation",
      description: "Bringing websites to life with immersive 3D experiences",
      color: "from-purple-500 to-pink-500",
      skills: [
        { name: "Three.js", level: 93 },
        { name: "WebGL & GLSL", level: 88 },
        { name: "GSAP", level: 95 },
        { name: "Blender", level: 82 },
        { name: "Unity", level: 75 }
      ]
    },
    {
      icon: <Server className="w-8 h-8" />,
      title: "Backend Development",
      description: "Building robust and scalable server-side applications",
      color: "from-green-500 to-emerald-500",
      skills: [
        { name: "Node.js & Express", level: 90 },
        { name: "Python & Django", level: 85 },
        { name: "GraphQL", level: 88 },
        { name: "REST APIs", level: 92 },
        { name: "Microservices", level: 80 }
      ]
    },
    {
      icon: <Database className="w-8 h-8" />,
      title: "Database & Cloud",
      description: "Managing data and deploying applications at scale",
      color: "from-orange-500 to-red-500",
      skills: [
        { name: "PostgreSQL", level: 88 },
        { name: "MongoDB", level: 85 },
        { name: "Redis", level: 82 },
        { name: "AWS", level: 80 },
        { name: "Docker", level: 85 }
      ]
    },
    {
      icon: <Brain className="w-8 h-8" />,
      title: "AI & Machine Learning",
      description: "Integrating intelligent features and data-driven solutions",
      color: "from-indigo-500 to-purple-500",
      skills: [
        { name: "TensorFlow.js", level: 82 },
        { name: "Python ML", level: 85 },
        { name: "Computer Vision", level: 78 },
        { name: "NLP", level: 75 },
        { name: "Data Analysis", level: 80 }
      ]
    },
    {
      icon: <Smartphone className="w-8 h-8" />,
      title: "Mobile Development",
      description: "Cross-platform mobile applications with native performance",
      color: "from-teal-500 to-blue-500",
      skills: [
        { name: "React Native", level: 88 },
        { name: "Flutter", level: 82 },
        { name: "iOS (Swift)", level: 75 },
        { name: "Android (Kotlin)", level: 78 },
        { name: "PWA", level: 90 }
      ]
    }
  ];

  const tools = [
    { name: "VS Code", icon: "💻", category: "Editor" },
    { name: "Figma", icon: "🎨", category: "Design" },
    { name: "Blender", icon: "🎭", category: "3D" },
    { name: "Git", icon: "📝", category: "Version Control" },
    { name: "Docker", icon: "🐳", category: "DevOps" },
    { name: "Webpack", icon: "📦", category: "Build Tools" },
    { name: "Jest", icon: "🧪", category: "Testing" },
    { name: "Postman", icon: "📡", category: "API" },
    { name: "Photoshop", icon: "🖼️", category: "Graphics" },
    { name: "After Effects", icon: "🎬", category: "Animation" },
    { name: "Notion", icon: "📋", category: "Productivity" },
    { name: "Slack", icon: "💬", category: "Communication" }
  ];

  const certifications = [
    {
      title: "AWS Certified Developer",
      issuer: "Amazon Web Services",
      date: "2024",
      badge: "🏆",
      color: "from-orange-500 to-red-500"
    },
    {
      title: "Google Cloud Professional",
      issuer: "Google Cloud",
      date: "2023",
      badge: "☁️",
      color: "from-blue-500 to-cyan-500"
    },
    {
      title: "React Advanced Certification",
      issuer: "Meta",
      date: "2023",
      badge: "⚛️",
      color: "from-blue-400 to-blue-600"
    },
    {
      title: "Three.js Specialist",
      issuer: "Three.js Foundation",
      date: "2024",
      badge: "🎯",
      color: "from-purple-500 to-pink-500"
    },
    {
      title: "Machine Learning Engineer",
      issuer: "TensorFlow",
      date: "2023",
      badge: "🤖",
      color: "from-green-500 to-emerald-500"
    },
    {
      title: "UI/UX Design Professional",
      issuer: "Adobe",
      date: "2022",
      badge: "🎨",
      color: "from-pink-500 to-purple-500"
    }
  ];

  return (
    <div className="page-transition">
      <section ref={sectionRef} className="min-h-screen pt-20">
        {/* Hero Section */}
        <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
            <Scene3D containerId="skills-scene" className="w-full h-full" />
          </div>
          
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/30 to-black/70 z-10" />
          
          <div className="relative z-20 text-center px-4 max-w-6xl mx-auto">
            <h1 className="text-6xl md:text-8xl font-bold text-white mb-8 tracking-tight">
              Skills & Expertise
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 max-w-4xl mx-auto leading-relaxed">
              A comprehensive overview of my technical skills, tools, and certifications 
              that enable me to create exceptional digital experiences.
            </p>
          </div>
        </div>

        {/* Skill Categories */}
        <div ref={skillCategoriesRef} className="py-20 px-4 bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 tracking-tight">
                Technical Skills
              </h2>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                Expertise across the full spectrum of modern web development and emerging technologies.
              </p>
            </div>

            <div className="grid lg:grid-cols-2 gap-8">
              {skillCategories.map((category, index) => (
                <div 
                  key={category.title}
                  className="skill-category group bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-all duration-500 cursor-pointer"
                >
                  <div className="flex items-center mb-6">
                    <div className={`p-4 bg-gradient-to-r ${category.color} rounded-2xl text-white mr-4 group-hover:scale-110 transition-transform duration-500`}>
                      {category.icon}
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-white group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:from-blue-400 group-hover:to-purple-500 transition-all duration-500">
                        {category.title}
                      </h3>
                      <p className="text-gray-400 text-sm">{category.description}</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    {category.skills.map((skill, skillIndex) => (
                      <div key={skill.name} className="group/skill">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-white font-medium group-hover/skill:text-blue-400 transition-colors duration-300">
                            {skill.name}
                          </span>
                          <span className="text-gray-300 text-sm">{skill.level}%</span>
                        </div>
                        <div className="w-full bg-gray-700/50 rounded-full h-2 overflow-hidden">
                          <div 
                            className={`skill-progress h-full bg-gradient-to-r ${category.color} rounded-full transition-all duration-1000 ease-out`}
                            data-progress={skill.level}
                          />
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Glow effect */}
                  <div className={`absolute -inset-2 bg-gradient-to-r ${category.color} opacity-0 group-hover:opacity-20 transition-opacity duration-500 rounded-2xl blur-xl`} />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Tools & Technologies */}
        <div ref={toolsRef} className="py-20 px-4 bg-gradient-to-br from-purple-900 via-blue-900 to-gray-900">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 tracking-tight">
                Tools & Technologies
              </h2>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                The arsenal of tools and technologies I use to bring ideas to life.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {tools.map((tool, index) => (
                <div 
                  key={tool.name}
                  className="tool-item group bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:bg-white/10 transition-all duration-300 text-center cursor-pointer"
                >
                  <div className="text-4xl mb-3 group-hover:scale-125 transition-transform duration-300">
                    {tool.icon}
                  </div>
                  <h3 className="text-white font-semibold mb-1 group-hover:text-blue-400 transition-colors duration-300">
                    {tool.name}
                  </h3>
                  <p className="text-gray-400 text-xs">{tool.category}</p>
                  
                  {/* Glow effect */}
                  <div className="absolute -inset-2 bg-gradient-to-r from-blue-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-xl blur-xl" />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Certifications */}
        <div ref={certificationsRef} className="py-20 px-4 bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 tracking-tight">
                Certifications & Achievements
              </h2>
              <p className="text-xl text-gray-300 max-w-3xl mx-auto">
                Professional certifications that validate my expertise and commitment to continuous learning.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {certifications.map((cert, index) => (
                <div 
                  key={cert.title}
                  className="certification-card group bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:bg-white/10 transition-all duration-500 cursor-pointer"
                >
                  <div className="flex items-start mb-4">
                    <div className={`text-4xl mr-4 group-hover:scale-110 transition-transform duration-500`}>
                      {cert.badge}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-white mb-2 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:from-blue-400 group-hover:to-purple-500 transition-all duration-500">
                        {cert.title}
                      </h3>
                      <p className="text-blue-400 font-medium mb-1">{cert.issuer}</p>
                      <p className="text-gray-400 text-sm">{cert.date}</p>
                    </div>
                  </div>
                  
                  <div className={`w-full h-1 bg-gradient-to-r ${cert.color} rounded-full opacity-50 group-hover:opacity-100 transition-opacity duration-500`} />
                  
                  {/* Glow effect */}
                  <div className={`absolute -inset-2 bg-gradient-to-r ${cert.color} opacity-0 group-hover:opacity-20 transition-opacity duration-500 rounded-2xl blur-xl`} />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Learning & Growth */}
        <div className="py-20 px-4 bg-gradient-to-br from-blue-900 via-purple-900 to-gray-900">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-5xl md:text-6xl font-bold text-white mb-8 tracking-tight">
              Continuous Learning
            </h2>
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
              <p className="text-xl text-gray-300 leading-relaxed mb-6">
                Technology evolves rapidly, and I'm committed to staying at the forefront of innovation. 
                I regularly explore emerging technologies, contribute to open-source projects, and share 
                knowledge with the developer community.
              </p>
              <p className="text-lg text-gray-400 leading-relaxed mb-8">
                Currently exploring: WebAssembly, AR/VR development, AI-powered development tools, 
                and advanced WebGL techniques for next-generation web experiences.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button className="px-8 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold rounded-full hover:shadow-lg hover:scale-105 transition-all duration-300">
                  View My Learning Journey
                </button>
                <button className="px-8 py-3 border-2 border-white/30 text-white font-semibold rounded-full hover:bg-white/10 transition-all duration-300">
                  Connect & Learn Together
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};