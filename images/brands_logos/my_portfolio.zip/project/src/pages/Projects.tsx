import React, { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Scene3D } from '../components/Scene3D';
import { ExternalLink, Github, Play, Filter, Search } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export const Projects: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const projectsRef = useRef<HTMLDivElement>(null);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo('.project-card',
        { y: 100, opacity: 0, rotationY: 45, scale: 0.8 },
        {
          y: 0,
          opacity: 1,
          rotationY: 0,
          scale: 1,
          duration: 1.2,
          stagger: 0.2,
          ease: "power3.out",
          scrollTrigger: {
            trigger: projectsRef.current,
            start: "top bottom-=100",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Hover animations for project cards
      document.querySelectorAll('.project-card').forEach(card => {
        const handleMouseEnter = () => {
          gsap.to(card, {
            y: -20,
            scale: 1.05,
            duration: 0.4,
            ease: "power2.out"
          });
        };

        const handleMouseLeave = () => {
          gsap.to(card, {
            y: 0,
            scale: 1,
            duration: 0.4,
            ease: "power2.out"
          });
        };

        card.addEventListener('mouseenter', handleMouseEnter);
        card.addEventListener('mouseleave', handleMouseLeave);
      });

    }, sectionRef);

    return () => ctx.revert();
  }, [selectedCategory]);

  const categories = ['All', '3D Web', 'React Apps', 'WebGL', 'AI/ML', 'Mobile'];

  const projects = [
    {
      id: 1,
      title: "Immersive 3D Portfolio",
      description: "A cutting-edge portfolio website featuring advanced Three.js animations, particle systems, and interactive 3D elements with real-time lighting and shadows.",
      image: "https://images.pexels.com/photos/1181472/pexels-photo-1181472.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "3D Web",
      technologies: ["React", "Three.js", "GSAP", "WebGL", "TypeScript"],
      github: "#",
      live: "#",
      featured: true
    },
    {
      id: 2,
      title: "AI-Powered Code Editor",
      description: "An intelligent code editor with AI-assisted coding, real-time collaboration, syntax highlighting, and advanced debugging features.",
      image: "https://images.pexels.com/photos/1181675/pexels-photo-1181675.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "AI/ML",
      technologies: ["React", "Monaco Editor", "WebSocket", "AI/ML", "Node.js"],
      github: "#",
      live: "#",
      featured: true
    },
    {
      id: 3,
      title: "WebGL Particle Simulator",
      description: "A physics-based particle simulation system using WebGL shaders for real-time rendering of complex particle interactions and fluid dynamics.",
      image: "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "WebGL",
      technologies: ["WebGL", "GLSL", "Three.js", "Physics Engine"],
      github: "#",
      live: "#",
      featured: false
    },
    {
      id: 4,
      title: "Real-time Collaboration Platform",
      description: "A multi-user workspace with live cursors, real-time document editing, video conferencing, and seamless synchronization across devices.",
      image: "https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "React Apps",
      technologies: ["React", "WebRTC", "Socket.io", "MongoDB", "Redis"],
      github: "#",
      live: "#",
      featured: true
    },
    {
      id: 5,
      title: "AR Product Visualizer",
      description: "An augmented reality application for visualizing products in real environments using WebXR and advanced 3D rendering techniques.",
      image: "https://images.pexels.com/photos/590022/pexels-photo-590022.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "3D Web",
      technologies: ["WebXR", "Three.js", "React", "Computer Vision"],
      github: "#",
      live: "#",
      featured: false
    },
    {
      id: 6,
      title: "Blockchain Data Visualizer",
      description: "Interactive 3D visualization of blockchain networks with real-time transaction tracking, network analysis, and performance metrics.",
      image: "https://images.pexels.com/photos/730547/pexels-photo-730547.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "3D Web",
      technologies: ["Web3.js", "Three.js", "D3.js", "Ethereum", "React"],
      github: "#",
      live: "#",
      featured: false
    },
    {
      id: 7,
      title: "Neural Network Visualizer",
      description: "An interactive tool for visualizing and understanding neural network architectures with real-time training visualization and performance analysis.",
      image: "https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "AI/ML",
      technologies: ["TensorFlow.js", "React", "D3.js", "Python", "WebGL"],
      github: "#",
      live: "#",
      featured: true
    },
    {
      id: 8,
      title: "Mobile Game Engine",
      description: "A lightweight 2D game engine for mobile devices with physics simulation, sprite animation, and cross-platform compatibility.",
      image: "https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "Mobile",
      technologies: ["React Native", "WebGL", "Physics Engine", "TypeScript"],
      github: "#",
      live: "#",
      featured: false
    },
    {
      id: 9,
      title: "Interactive Data Dashboard",
      description: "A comprehensive analytics dashboard with real-time data visualization, interactive charts, and advanced filtering capabilities.",
      image: "https://images.pexels.com/photos/669610/pexels-photo-669610.jpeg?auto=compress&cs=tinysrgb&w=800",
      category: "React Apps",
      technologies: ["React", "D3.js", "WebSocket", "PostgreSQL", "Redis"],
      github: "#",
      live: "#",
      featured: false
    }
  ];

  const filteredProjects = projects.filter(project => {
    const matchesCategory = selectedCategory === 'All' || project.category === selectedCategory;
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.technologies.some(tech => tech.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const featuredProjects = filteredProjects.filter(project => project.featured);
  const regularProjects = filteredProjects.filter(project => !project.featured);

  return (
    <div className="page-transition">
      <section ref={sectionRef} className="min-h-screen pt-20">
        {/* Hero Section */}
        <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
            <Scene3D containerId="projects-scene" className="w-full h-full" />
          </div>
          
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/30 to-black/70 z-10" />
          
          <div className="relative z-20 text-center px-4 max-w-6xl mx-auto">
            <h1 className="text-6xl md:text-8xl font-bold text-white mb-8 tracking-tight">
              My Projects
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 max-w-4xl mx-auto leading-relaxed">
              A showcase of innovative solutions, cutting-edge technologies, and creative problem-solving 
              that push the boundaries of what's possible on the web.
            </p>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="py-12 px-4 bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col lg:flex-row gap-6 items-center justify-between mb-12">
              {/* Category Filters */}
              <div className="flex flex-wrap gap-3">
                <Filter className="w-5 h-5 text-gray-400 mt-2" />
                {categories.map(category => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-6 py-2 rounded-full font-medium transition-all duration-300 ${
                      selectedCategory === category
                        ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg'
                        : 'bg-white/10 text-gray-300 hover:bg-white/20 hover:text-white'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>

              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search projects..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-full text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 w-64"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Featured Projects */}
        {featuredProjects.length > 0 && (
          <div className="py-20 px-4 bg-gradient-to-br from-purple-900 via-blue-900 to-gray-900">
            <div className="max-w-7xl mx-auto">
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-12 text-center">
                Featured Projects
              </h2>
              
              <div className="grid lg:grid-cols-2 gap-8">
                {featuredProjects.map((project, index) => (
                  <div 
                    key={project.id}
                    className="project-card group relative bg-white/5 backdrop-blur-sm rounded-2xl overflow-hidden border border-white/10 hover:bg-white/10 transition-all duration-500 cursor-pointer"
                    style={{ perspective: '1000px' }}
                  >
                    <div className="relative overflow-hidden">
                      <img 
                        src={project.image} 
                        alt={project.title}
                        className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                      
                      {/* Action buttons */}
                      <div className="absolute top-4 right-4 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <a 
                          href={project.github}
                          className="p-3 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 transition-all duration-300 transform hover:scale-110"
                        >
                          <Github size={18} />
                        </a>
                        <a 
                          href={project.live}
                          className="p-3 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 transition-all duration-300 transform hover:scale-110"
                        >
                          <ExternalLink size={18} />
                        </a>
                        <button className="p-3 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 transition-all duration-300 transform hover:scale-110">
                          <Play size={18} />
                        </button>
                      </div>

                      {/* Featured badge */}
                      <div className="absolute top-4 left-4">
                        <span className="px-3 py-1 bg-gradient-to-r from-yellow-500 to-orange-500 text-white text-xs font-bold rounded-full">
                          FEATURED
                        </span>
                      </div>
                    </div>
                    
                    <div className="p-8">
                      <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:from-blue-400 group-hover:to-purple-500 transition-all duration-500">
                        {project.title}
                      </h3>
                      <p className="text-gray-300 text-sm mb-6 leading-relaxed group-hover:text-gray-200 transition-colors duration-500">
                        {project.description}
                      </p>
                      
                      <div className="flex flex-wrap gap-2">
                        {project.technologies.map((tech) => (
                          <span 
                            key={tech}
                            className="px-3 py-1 bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-white text-xs rounded-full border border-white/10 hover:border-white/30 transition-all duration-300"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Glow effect */}
                    <div className="absolute -inset-2 bg-gradient-to-r from-blue-500/20 via-purple-500/20 to-pink-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl blur-xl" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* All Projects */}
        <div ref={projectsRef} className="py-20 px-4 bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900">
          <div className="max-w-7xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-12 text-center">
              All Projects
            </h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {regularProjects.map((project, index) => (
                <div 
                  key={project.id}
                  className="project-card group relative bg-white/5 backdrop-blur-sm rounded-2xl overflow-hidden border border-white/10 hover:bg-white/10 transition-all duration-500 cursor-pointer"
                  style={{ perspective: '1000px' }}
                >
                  <div className="relative overflow-hidden">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-48 object-cover transition-transform duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    
                    {/* Action buttons */}
                    <div className="absolute top-4 right-4 flex space-x-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <a 
                        href={project.github}
                        className="p-2 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 transition-all duration-300"
                      >
                        <Github size={16} />
                      </a>
                      <a 
                        href={project.live}
                        className="p-2 bg-black/50 backdrop-blur-sm rounded-full text-white hover:bg-black/70 transition-all duration-300"
                      >
                        <ExternalLink size={16} />
                      </a>
                    </div>

                    {/* Category badge */}
                    <div className="absolute top-4 left-4">
                      <span className="px-2 py-1 bg-gradient-to-r from-blue-500/80 to-purple-500/80 text-white text-xs font-medium rounded-full">
                        {project.category}
                      </span>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-white mb-3 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:from-blue-400 group-hover:to-purple-500 transition-all duration-500">
                      {project.title}
                    </h3>
                    <p className="text-gray-300 text-sm mb-4 leading-relaxed group-hover:text-gray-200 transition-colors duration-500">
                      {project.description}
                    </p>
                    
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.slice(0, 3).map((tech) => (
                        <span 
                          key={tech}
                          className="px-2 py-1 bg-gradient-to-r from-blue-500/20 to-purple-500/20 text-white text-xs rounded-full border border-white/10"
                        >
                          {tech}
                        </span>
                      ))}
                      {project.technologies.length > 3 && (
                        <span className="px-2 py-1 bg-gray-500/20 text-gray-400 text-xs rounded-full">
                          +{project.technologies.length - 3}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Glow effect */}
                  <div className="absolute -inset-2 bg-gradient-to-r from-blue-500/20 to-purple-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl blur-xl" />
                </div>
              ))}
            </div>

            {filteredProjects.length === 0 && (
              <div className="text-center py-20">
                <div className="text-6xl mb-4">🔍</div>
                <h3 className="text-2xl font-bold text-white mb-4">No projects found</h3>
                <p className="text-gray-400">Try adjusting your search or filter criteria.</p>
              </div>
            )}
          </div>
        </div>

        {/* Call to Action */}
        <div className="py-20 px-4 bg-gradient-to-br from-blue-900 via-purple-900 to-gray-900">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-8">
              Ready to Start Your Project?
            </h2>
            <p className="text-xl text-gray-300 mb-12 leading-relaxed">
              Let's collaborate and bring your vision to life with cutting-edge technology and creative innovation.
            </p>
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <button className="px-10 py-4 bg-gradient-to-r from-blue-500 to-purple-600 text-white text-lg font-semibold rounded-full hover:shadow-lg hover:scale-105 transition-all duration-300">
                Start a Project
              </button>
              <button className="px-10 py-4 border-2 border-white/30 text-white text-lg font-semibold rounded-full hover:bg-white/10 transition-all duration-300">
                View More Work
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};