import React, { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Scene3D } from '../components/Scene3D';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Send, 
  Github, 
  Linkedin, 
  Twitter,
  Calendar,
  MessageCircle,
  Clock,
  CheckCircle
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export const Contact: React.FC = () => {
  const sectionRef = useRef<HTMLElement>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const contactCardsRef = useRef<HTMLDivElement[]>([]);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    subject: '',
    message: '',
    projectType: '',
    budget: '',
    timeline: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(formRef.current, 
        { 
          x: -100, 
          opacity: 0,
          rotationY: 45
        },
        {
          x: 0, 
          opacity: 1,
          rotationY: 0,
          duration: 1.2,
          ease: "power3.out",
          scrollTrigger: {
            trigger: formRef.current,
            start: "top bottom-=100",
            toggleActions: "play none none reverse"
          }
        }
      );

      contactCardsRef.current.forEach((card, index) => {
        gsap.fromTo(card, 
          { 
            x: 100, 
            opacity: 0,
            rotationY: -45
          },
          {
            x: 0, 
            opacity: 1,
            rotationY: 0,
            duration: 1.2,
            delay: index * 0.2,
            ease: "power3.out",
            scrollTrigger: {
              trigger: card,
              start: "top bottom-=100",
              toggleActions: "play none none reverse"
            }
          }
        );

        // Floating animation
        gsap.to(card, {
          y: -10,
          duration: 2 + index * 0.3,
          repeat: -1,
          yoyo: true,
          ease: "power2.inOut",
          delay: index * 0.2
        });
      });

    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    setIsSubmitting(false);
    setIsSubmitted(true);
    
    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        subject: '',
        message: '',
        projectType: '',
        budget: '',
        timeline: ''
      });
    }, 3000);
  };

  const contactInfo = [
    {
      icon: <Mail className="w-6 h-6" />,
      title: "Email",
      value: "harsh.kuhikar@gmail.com",
      description: "Drop me a line anytime",
      color: "from-blue-500 to-cyan-500",
      action: "mailto:harsh.kuhikar@gmail.com"
    },
    {
      icon: <Phone className="w-6 h-6" />,
      title: "Phone",
      value: "+1 (555) 123-4567",
      description: "Call for urgent projects",
      color: "from-green-500 to-emerald-500",
      action: "tel:+15551234567"
    },
    {
      icon: <MapPin className="w-6 h-6" />,
      title: "Location",
      value: "San Francisco, CA",
      description: "Available for remote work",
      color: "from-purple-500 to-pink-500",
      action: "#"
    },
    {
      icon: <Calendar className="w-6 h-6" />,
      title: "Schedule",
      value: "Book a Meeting",
      description: "Let's discuss your project",
      color: "from-orange-500 to-red-500",
      action: "#"
    }
  ];

  const socialLinks = [
    { 
      icon: <Github className="w-5 h-5" />, 
      url: "https://github.com/harshkuhikar", 
      label: "GitHub",
      color: "from-gray-600 to-gray-800"
    },
    { 
      icon: <Linkedin className="w-5 h-5" />, 
      url: "https://linkedin.com/in/harshkuhikar", 
      label: "LinkedIn",
      color: "from-blue-600 to-blue-800"
    },
    { 
      icon: <Twitter className="w-5 h-5" />, 
      url: "https://twitter.com/harshkuhikar", 
      label: "Twitter",
      color: "from-blue-400 to-blue-600"
    },
    { 
      icon: <MessageCircle className="w-5 h-5" />, 
      url: "#", 
      label: "Discord",
      color: "from-indigo-500 to-purple-600"
    }
  ];

  const projectTypes = [
    "Website Development",
    "3D Web Experience",
    "Mobile Application",
    "E-commerce Platform",
    "Custom Software",
    "Consultation",
    "Other"
  ];

  const budgetRanges = [
    "Under $5,000",
    "$5,000 - $15,000",
    "$15,000 - $50,000",
    "$50,000 - $100,000",
    "$100,000+",
    "Let's discuss"
  ];

  const timelineOptions = [
    "ASAP",
    "1-2 weeks",
    "1 month",
    "2-3 months",
    "3-6 months",
    "6+ months",
    "Flexible"
  ];

  return (
    <div className="page-transition">
      <section ref={sectionRef} className="min-h-screen pt-20">
        {/* Hero Section */}
        <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0">
            <Scene3D containerId="contact-scene" className="w-full h-full" />
          </div>
          
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/30 to-black/70 z-10" />
          
          <div className="relative z-20 text-center px-4 max-w-6xl mx-auto">
            <h1 className="text-6xl md:text-8xl font-bold text-white mb-8 tracking-tight">
              Let's Connect
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 max-w-4xl mx-auto leading-relaxed">
              Ready to bring your vision to life? Let's discuss your project and create 
              something extraordinary together.
            </p>
          </div>
        </div>

        {/* Contact Form & Info */}
        <div className="py-20 px-4 bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
          <div className="max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Contact Form */}
              <div>
                <div className="mb-8">
                  <h2 className="text-4xl font-bold text-white mb-4">Start Your Project</h2>
                  <p className="text-gray-300 text-lg">
                    Fill out the form below and I'll get back to you within 24 hours.
                  </p>
                </div>

                <form 
                  ref={formRef}
                  onSubmit={handleSubmit}
                  className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 space-y-6"
                >
                  {!isSubmitted ? (
                    <>
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-white font-medium mb-2">First Name *</label>
                          <input 
                            type="text" 
                            name="firstName"
                            value={formData.firstName}
                            onChange={handleInputChange}
                            required
                            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                            placeholder="John"
                          />
                        </div>
                        <div>
                          <label className="block text-white font-medium mb-2">Last Name *</label>
                          <input 
                            type="text" 
                            name="lastName"
                            value={formData.lastName}
                            onChange={handleInputChange}
                            required
                            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                            placeholder="Doe"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <label className="block text-white font-medium mb-2">Email *</label>
                        <input 
                          type="email" 
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          required
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                          placeholder="john@example.com"
                        />
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-white font-medium mb-2">Project Type</label>
                          <select 
                            name="projectType"
                            value={formData.projectType}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                          >
                            <option value="">Select type</option>
                            {projectTypes.map(type => (
                              <option key={type} value={type} className="bg-gray-800">{type}</option>
                            ))}
                          </select>
                        </div>
                        <div>
                          <label className="block text-white font-medium mb-2">Budget Range</label>
                          <select 
                            name="budget"
                            value={formData.budget}
                            onChange={handleInputChange}
                            className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                          >
                            <option value="">Select budget</option>
                            {budgetRanges.map(range => (
                              <option key={range} value={range} className="bg-gray-800">{range}</option>
                            ))}
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-white font-medium mb-2">Timeline</label>
                        <select 
                          name="timeline"
                          value={formData.timeline}
                          onChange={handleInputChange}
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                        >
                          <option value="">Select timeline</option>
                          {timelineOptions.map(option => (
                            <option key={option} value={option} className="bg-gray-800">{option}</option>
                          ))}
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-white font-medium mb-2">Subject *</label>
                        <input 
                          type="text" 
                          name="subject"
                          value={formData.subject}
                          onChange={handleInputChange}
                          required
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300"
                          placeholder="Project Discussion"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-white font-medium mb-2">Message *</label>
                        <textarea 
                          rows={5}
                          name="message"
                          value={formData.message}
                          onChange={handleInputChange}
                          required
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-300 resize-none"
                          placeholder="Tell me about your project, goals, and any specific requirements..."
                        />
                      </div>
                      
                      <button 
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-4 rounded-lg font-semibold hover:shadow-lg hover:scale-105 transition-all duration-300 flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {isSubmitting ? (
                          <>
                            <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                            <span>Sending...</span>
                          </>
                        ) : (
                          <>
                            <Send className="w-5 h-5" />
                            <span>Send Message</span>
                          </>
                        )}
                      </button>
                    </>
                  ) : (
                    <div className="text-center py-12">
                      <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                        <CheckCircle className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold text-white mb-2">Message Sent!</h3>
                      <p className="text-gray-300">
                        Thank you for reaching out. I'll get back to you within 24 hours.
                      </p>
                    </div>
                  )}
                </form>
              </div>

              {/* Contact Info */}
              <div className="space-y-6">
                <div className="mb-8">
                  <h2 className="text-4xl font-bold text-white mb-4">Get In Touch</h2>
                  <p className="text-gray-300 text-lg">
                    Multiple ways to reach me. Choose what works best for you.
                  </p>
                </div>

                {contactInfo.map((info, index) => (
                  <div 
                    key={info.title}
                    ref={el => el && (contactCardsRef.current[index] = el)}
                    className="group bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:bg-white/10 transition-all duration-500 cursor-pointer"
                  >
                    <a href={info.action} className="flex items-center space-x-4">
                      <div className={`p-4 bg-gradient-to-r ${info.color} rounded-2xl text-white group-hover:scale-110 transition-transform duration-500`}>
                        {info.icon}
                      </div>
                      <div className="flex-1">
                        <h3 className="text-white font-semibold text-lg group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:from-blue-400 group-hover:to-purple-500 transition-all duration-500">
                          {info.title}
                        </h3>
                        <p className="text-blue-400 font-medium">{info.value}</p>
                        <p className="text-gray-400 text-sm">{info.description}</p>
                      </div>
                    </a>
                    
                    {/* Glow effect */}
                    <div className={`absolute -inset-2 bg-gradient-to-r ${info.color} opacity-0 group-hover:opacity-20 transition-opacity duration-500 rounded-2xl blur-xl`} />
                  </div>
                ))}
                
                {/* Social Links */}
                <div 
                  ref={el => el && (contactCardsRef.current[4] = el)}
                  className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10"
                >
                  <h3 className="text-white font-semibold text-lg mb-4">Follow Me</h3>
                  <div className="grid grid-cols-2 gap-4">
                    {socialLinks.map((social, index) => (
                      <a 
                        key={social.label}
                        href={social.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={`group flex items-center space-x-3 p-3 bg-gradient-to-r ${social.color} rounded-xl text-white hover:scale-105 transition-all duration-300`}
                      >
                        {social.icon}
                        <span className="font-medium">{social.label}</span>
                      </a>
                    ))}
                  </div>
                </div>
                
                {/* Quick Response */}
                <div 
                  ref={el => el && (contactCardsRef.current[5] = el)}
                  className="bg-gradient-to-r from-blue-500/20 to-purple-500/20 backdrop-blur-sm rounded-2xl p-6 border border-white/10"
                >
                  <div className="flex items-center space-x-3 mb-3">
                    <Clock className="w-5 h-5 text-blue-400" />
                    <h3 className="text-white font-semibold">Quick Response</h3>
                  </div>
                  <p className="text-gray-300 text-sm leading-relaxed">
                    I typically respond within 24 hours. For urgent projects or quick questions, 
                    feel free to call me directly or reach out on social media.
                  </p>
                </div>

                {/* Availability */}
                <div 
                  ref={el => el && (contactCardsRef.current[6] = el)}
                  className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 backdrop-blur-sm rounded-2xl p-6 border border-white/10"
                >
                  <h3 className="text-white font-semibold mb-3">Current Availability</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">New Projects</span>
                      <span className="text-green-400 font-medium">Available</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Consultations</span>
                      <span className="text-green-400 font-medium">Open</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Response Time</span>
                      <span className="text-blue-400 font-medium">{'< 24 hours'}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="py-20 px-4 bg-gradient-to-br from-purple-900 via-blue-900 to-gray-900">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
                Frequently Asked Questions
              </h2>
              <p className="text-xl text-gray-300">
                Quick answers to common questions about working with me.
              </p>
            </div>

            <div className="space-y-6">
              {[
                {
                  question: "What's your typical project timeline?",
                  answer: "Project timelines vary based on complexity. Simple websites take 2-4 weeks, while complex 3D applications can take 2-6 months. I'll provide a detailed timeline during our initial consultation."
                },
                {
                  question: "Do you work with international clients?",
                  answer: "Absolutely! I work with clients worldwide and am comfortable with different time zones. I use modern collaboration tools to ensure smooth communication regardless of location."
                },
                {
                  question: "What's included in your development process?",
                  answer: "My process includes discovery, design, development, testing, deployment, and post-launch support. I provide regular updates and involve you in key decisions throughout the project."
                },
                {
                  question: "Can you help with existing projects?",
                  answer: "Yes! I can help optimize existing websites, add new features, fix bugs, or completely redesign your current project. I'm experienced in working with various codebases and technologies."
                }
              ].map((faq, index) => (
                <div key={index} className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10 hover:bg-white/10 transition-all duration-300">
                  <h3 className="text-white font-semibold text-lg mb-3">{faq.question}</h3>
                  <p className="text-gray-300 leading-relaxed">{faq.answer}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};