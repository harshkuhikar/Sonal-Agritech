import React, { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Scene3D } from '../components/Scene3D';
import { ChevronDown, Sparkles, Zap, Rocket } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export const Home: React.FC = () => {
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const featuresRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Hero entrance animation
      const tl = gsap.timeline();
      
      tl.fromTo(titleRef.current, 
        { y: 100, opacity: 0, rotationX: 45 },
        { y: 0, opacity: 1, rotationX: 0, duration: 1.5, ease: "power3.out" }
      )
      .fromTo(subtitleRef.current,
        { y: 50, opacity: 0 },
        { y: 0, opacity: 1, duration: 1.2, ease: "power3.out" },
        "-=1"
      )
      .fromTo(ctaRef.current,
        { scale: 0, opacity: 0, rotationY: 180 },
        { scale: 1, opacity: 1, rotationY: 0, duration: 1, ease: "back.out(1.7)" },
        "-=0.5"
      );

      // Continuous floating animations
      gsap.to(titleRef.current, {
        y: -20,
        duration: 3,
        repeat: -1,
        yoyo: true,
        ease: "power2.inOut"
      });

      gsap.to(subtitleRef.current, {
        y: -10,
        duration: 2.5,
        repeat: -1,
        yoyo: true,
        ease: "power2.inOut",
        delay: 0.5
      });

      // Features scroll animation
      gsap.fromTo('.feature-card',
        { y: 100, opacity: 0, rotationY: 45 },
        {
          y: 0,
          opacity: 1,
          rotationY: 0,
          duration: 1,
          stagger: 0.2,
          ease: "power3.out",
          scrollTrigger: {
            trigger: featuresRef.current,
            start: "top bottom-=100",
            end: "bottom top",
            toggleActions: "play none none reverse"
          }
        }
      );

      // Parallax effect for hero section
      gsap.to(heroRef.current, {
        yPercent: -50,
        ease: "none",
        scrollTrigger: {
          trigger: heroRef.current,
          start: "top bottom",
          end: "bottom top",
          scrub: true
        }
      });

    }, heroRef);

    return () => ctx.revert();
  }, []);

  const features = [
    {
      icon: <Sparkles className="w-8 h-8" />,
      title: "3D Animations",
      description: "Cutting-edge Three.js animations that bring websites to life with stunning visual effects.",
      gradient: "from-blue-500 to-cyan-500"
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Performance",
      description: "Optimized code and efficient rendering for smooth 60fps experiences across all devices.",
      gradient: "from-purple-500 to-pink-500"
    },
    {
      icon: <Rocket className="w-8 h-8" />,
      title: "Innovation",
      description: "Pushing the boundaries of web development with experimental technologies and creative solutions.",
      gradient: "from-green-500 to-emerald-500"
    }
  ];

  return (
    <div className="page-transition">
      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Scene3D containerId="home-scene" className="w-full h-full" />
        </div>
        
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/60 z-10" />
        
        <div className="relative z-20 text-center px-4 max-w-6xl mx-auto">
          <h1 
            ref={titleRef}
            className="text-6xl md:text-8xl lg:text-9xl font-bold mb-8 tracking-tight"
            style={{
              background: 'linear-gradient(45deg, #667eea, #764ba2, #f093fb, #f5576c, #4facfe, #00f2fe)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundSize: '400% 400%',
              animation: 'gradientShift 4s ease infinite'
            }}
          >
            HARSH KUHIKAR
          </h1>
          
          <p 
            ref={subtitleRef}
            className="text-xl md:text-3xl lg:text-4xl text-gray-200 mb-12 max-w-4xl mx-auto leading-relaxed font-light"
          >
            Creative Developer & 3D Animation Specialist
            <br />
            <span className="text-lg md:text-xl lg:text-2xl text-blue-400">
              Crafting immersive digital experiences that push the boundaries of web development
            </span>
          </p>
          
          <div ref={ctaRef} className="flex flex-col sm:flex-row gap-6 justify-center items-center">
            <button className="group relative px-10 py-4 bg-gradient-to-r from-blue-500 via-purple-600 to-pink-500 text-white text-lg font-semibold rounded-full transition-all duration-500 transform hover:scale-110 hover:shadow-2xl overflow-hidden">
              <span className="relative z-10">Explore My Work</span>
              <div className="absolute inset-0 bg-gradient-to-r from-pink-500 via-purple-600 to-blue-500 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="absolute -inset-2 bg-gradient-to-r from-blue-500 via-purple-600 to-pink-500 rounded-full opacity-20 group-hover:opacity-40 transition-opacity duration-500 blur-xl" />
            </button>
            
            <button className="group relative px-10 py-4 border-2 border-white/30 text-white text-lg font-semibold rounded-full transition-all duration-500 transform hover:scale-110 hover:bg-white/10 backdrop-blur-sm">
              <span className="relative z-10">Get In Touch</span>
              <div className="absolute -inset-2 bg-gradient-to-r from-blue-400/20 via-purple-500/20 to-pink-500/20 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-500 blur-xl" />
            </button>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 text-white animate-bounce z-20">
          <div className="flex flex-col items-center space-y-2">
            <span className="text-sm font-medium">Scroll to explore</span>
            <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
              <ChevronDown className="w-4 h-4 mt-2 animate-pulse" />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section ref={featuresRef} className="py-32 px-4 bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIyMCIgcj0iMSIgZmlsbD0iIzMzMzMzMyIgZmlsbC1vcGFjaXR5PSIwLjEiLz4KPC9zdmc+')] opacity-50" />
        
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="text-center mb-20">
            <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 tracking-tight">
              What I Bring
            </h2>
            <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Combining cutting-edge technology with creative vision to deliver exceptional digital experiences.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div 
                key={feature.title}
                className="feature-card group relative bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 hover:bg-white/10 transition-all duration-500 cursor-pointer overflow-hidden"
                style={{ perspective: '1000px' }}
              >
                <div className="relative z-10">
                  <div className={`inline-flex p-4 bg-gradient-to-r ${feature.gradient} rounded-2xl text-white mb-6 group-hover:scale-110 transition-transform duration-500`}>
                    {feature.icon}
                  </div>
                  
                  <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:bg-clip-text group-hover:from-blue-400 group-hover:to-purple-500 transition-all duration-500">
                    {feature.title}
                  </h3>
                  
                  <p className="text-gray-300 leading-relaxed group-hover:text-gray-200 transition-colors duration-500">
                    {feature.description}
                  </p>
                </div>
                
                {/* Animated background */}
                <div className={`absolute inset-0 bg-gradient-to-r ${feature.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-500 rounded-2xl`} />
                
                {/* Glow effect */}
                <div className={`absolute -inset-2 bg-gradient-to-r ${feature.gradient} opacity-0 group-hover:opacity-20 transition-opacity duration-500 rounded-2xl blur-xl`} />
              </div>
            ))}
          </div>
        </div>
      </section>

      <style jsx>{`
        @keyframes gradientShift {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
      `}</style>
    </div>
  );
};